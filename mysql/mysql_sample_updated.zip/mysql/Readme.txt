To compile this sample with ooHG V5.3 - 2012.10.18
you need libhbmysql.a (from c:\oohb\harbour\lib folder) and
LibDllMySql_O3GH.A (from C:\oohg\samples\mysql\LIB folder).
Use QPM v05.03.07 with project file: ooSQL.qpm

LibDllMySql_O3GH.A is builded from LIBMYSQL.DLL and libmysql.lib
files (see C:\oohg\samples\mysql folder) using QPM v05.03.07 and
build_lib.qpm project file.

Best regards
Fernando Yurisich
--
Q.P.M. is the continuation of Q.A.C. project manager for (x)Harbour and OOHG/Minigui based projects.
Visit us at http://sourceforge.net/p/qpm and join the user list.
For OOHG samples and documents, visit http://oohg.wikia.com/wiki/Object_Oriented_Harbour_GUI_Wiki
Please support me with a donation via PayPal.




