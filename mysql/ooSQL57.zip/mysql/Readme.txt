
To compile this sample you need:

1. Download 32 bits version of MySQL's Connector for C under Windows from:
   https://dev.mysql.com/downloads/connector/c/

2. Extract libmysql.dll and libmysql.lib from the downloaded package and
   copy them to this folder.

3. Double click on "build_lib.qpm"

4. Launch "Build" to generate "libDllMySql_O3GH.a"

5. Close QPM and double click on "ooSQL.qpm"

6. Launch "Build" to generate "sistema.exe"

Regards
Fernando Yurisich

----------------------------------------------------------------------

Para compilar este ejemplo se necesita:

1. Descargar la versi�n de 32 bits del Conector C para Windows desde:
   https://dev.mysql.com/downloads/connector/c/

2. Extraer libmysql.dll y libmysql.lib desde el paquete descarado y
   copiarlos a esta carpeta.

3. Hacer doble clic en "build_lib.qpm"

4. Lanzar "Build" para generar "libDllMySql_O3GH.a"

5. Cerrar QPM y hacer doble clic en "ooSQL.qpm"

6. Lanzar "Build" para generar "sistema.exe"

Saludos
Fernando Yurisich
