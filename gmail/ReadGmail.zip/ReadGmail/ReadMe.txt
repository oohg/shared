ReadGmail

This little example shows how to read emails from
Gmail pop3 server using the Chilkat ActiveX Mail 
component (Comercial). You can try a 30-Day Trial
demo here :

http://www.chilkatsoft.com/download/EmailActiveX.msi

Prior to read the mail server you must set the mail
account name and password using the Mail Account
Details option.

When you press the Read Mail option, the program 
freezes a while because it read all the mail
headers in a bulk using the command :

   loMail:GetAllHeaders(1)

Probably there are methods to do it more interactively
(Example : A progress bar while downloading), but
I have no investigate them.

Here is a reference of the methods of that component :

http://www.chilkatsoft.com/refdoc/xChilkatMailMan2Ref.html

Also in the site there are tons of Visual FoxPro / Visual
Basic Examples that can easily be converted to MiniGUI.

This example was compiled using ooHG v2008-07-24

Greats
Hugo Rozas Mory
hugo.rozas@gmail.com

Sep/2008

