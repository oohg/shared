/*
 * Harbour devel build 1.1-1 Intl.
 * Borland C++ 5.5.1 (32 bit)
 * Generated C source from "C:\HARBOU~3\contrib\hbpgsql\tests\DEMO_P~1\demo_postgres.prg"
 */
#include "hbvmpub.h"
#include "hbpcode.h"
#include "hbinit.h"


HB_FUNC( MAIN );
HB_FUNC( TABLA );
HB_FUNC( INSERTA );
HB_FUNC( BORRAR );
HB_FUNC( LEER );
HB_FUNC( ACTUALIZAR );
HB_FUNC( TERMINAR );
HB_FUNC_EXTERN( DEFINEWINDOW );
HB_FUNC_EXTERN( _OOHG_SELECTSUBCLASS );
HB_FUNC_EXTERN( TLABEL );
HB_FUNC_EXTERN( DEFINETEXTBOX );
HB_FUNC_EXTERN( TGRID );
HB_FUNC_EXTERN( TBUTTON );
HB_FUNC_EXTERN( _ENDWINDOW );
HB_FUNC_EXTERN( GETEXISTINGFORMOBJECT );
HB_FUNC_EXTERN( GETEXISTINGCONTROLOBJECT );
HB_FUNC_EXTERN( PQCONNECT );
HB_FUNC_EXTERN( PQSTATUS );
HB_FUNC_EXTERN( MSGINFO );
HB_FUNC_EXTERN( PQEXEC );
HB_FUNC_EXTERN( PQCLEAR );
HB_FUNC_EXTERN( STR );
HB_FUNC_EXTERN( STRZERO );
HB_FUNC_EXTERN( MOD );
HB_FUNC_EXTERN( PQGETVALUE );
HB_FUNC_EXTERN( PQRESULTSTATUS );
HB_FUNC_EXTERN( VAL );
HB_FUNC_EXTERN( PQCLOSE );


HB_INIT_SYMBOLS_BEGIN( hb_vm_SymbolInit_DEMO_POSTGRES )
{ "MAIN", {HB_FS_PUBLIC | HB_FS_FIRST | HB_FS_LOCAL}, {HB_FUNCNAME( MAIN )}, NULL },
{ "CSERVER", {HB_FS_PUBLIC | HB_FS_MEMVAR}, {NULL}, NULL },
{ "CDATABASE", {HB_FS_PUBLIC | HB_FS_MEMVAR}, {NULL}, NULL },
{ "CUSER", {HB_FS_PUBLIC | HB_FS_MEMVAR}, {NULL}, NULL },
{ "CPASS", {HB_FS_PUBLIC | HB_FS_MEMVAR}, {NULL}, NULL },
{ "CQUERY", {HB_FS_PUBLIC | HB_FS_MEMVAR}, {NULL}, NULL },
{ "DEFINEWINDOW", {HB_FS_PUBLIC}, {HB_FUNCNAME( DEFINEWINDOW )}, NULL },
{ "DEFINE", {HB_FS_PUBLIC | HB_FS_MESSAGE}, {NULL}, NULL },
{ "_OOHG_SELECTSUBCLASS", {HB_FS_PUBLIC}, {HB_FUNCNAME( _OOHG_SELECTSUBCLASS )}, NULL },
{ "TLABEL", {HB_FS_PUBLIC}, {HB_FUNCNAME( TLABEL )}, NULL },
{ "DEFINETEXTBOX", {HB_FS_PUBLIC}, {HB_FUNCNAME( DEFINETEXTBOX )}, NULL },
{ "TGRID", {HB_FS_PUBLIC}, {HB_FUNCNAME( TGRID )}, NULL },
{ "TBUTTON", {HB_FS_PUBLIC}, {HB_FUNCNAME( TBUTTON )}, NULL },
{ "TABLA", {HB_FS_PUBLIC | HB_FS_LOCAL}, {HB_FUNCNAME( TABLA )}, NULL },
{ "INSERTA", {HB_FS_PUBLIC | HB_FS_LOCAL}, {HB_FUNCNAME( INSERTA )}, NULL },
{ "LEER", {HB_FS_PUBLIC | HB_FS_LOCAL}, {HB_FUNCNAME( LEER )}, NULL },
{ "BORRAR", {HB_FS_PUBLIC | HB_FS_LOCAL}, {HB_FUNCNAME( BORRAR )}, NULL },
{ "TERMINAR", {HB_FS_PUBLIC | HB_FS_LOCAL}, {HB_FUNCNAME( TERMINAR )}, NULL },
{ "_ENDWINDOW", {HB_FS_PUBLIC}, {HB_FUNCNAME( _ENDWINDOW )}, NULL },
{ "CENTER", {HB_FS_PUBLIC | HB_FS_MESSAGE}, {NULL}, NULL },
{ "GETEXISTINGFORMOBJECT", {HB_FS_PUBLIC}, {HB_FUNCNAME( GETEXISTINGFORMOBJECT )}, NULL },
{ "ACTIVATE", {HB_FS_PUBLIC | HB_FS_MESSAGE}, {NULL}, NULL },
{ "_VALUE", {HB_FS_PUBLIC | HB_FS_MESSAGE}, {NULL}, NULL },
{ "GETEXISTINGCONTROLOBJECT", {HB_FS_PUBLIC}, {HB_FUNCNAME( GETEXISTINGCONTROLOBJECT )}, NULL },
{ "PQCONNECT", {HB_FS_PUBLIC}, {HB_FUNCNAME( PQCONNECT )}, NULL },
{ "CONN", {HB_FS_PUBLIC | HB_FS_MEMVAR}, {NULL}, NULL },
{ "PQSTATUS", {HB_FS_PUBLIC}, {HB_FUNCNAME( PQSTATUS )}, NULL },
{ "MSGINFO", {HB_FS_PUBLIC}, {HB_FUNCNAME( MSGINFO )}, NULL },
{ "PQEXEC", {HB_FS_PUBLIC}, {HB_FUNCNAME( PQEXEC )}, NULL },
{ "RES", {HB_FS_PUBLIC | HB_FS_MEMVAR}, {NULL}, NULL },
{ "PQCLEAR", {HB_FS_PUBLIC}, {HB_FUNCNAME( PQCLEAR )}, NULL },
{ "I", {HB_FS_PUBLIC | HB_FS_MEMVAR}, {NULL}, NULL },
{ "STR", {HB_FS_PUBLIC}, {HB_FUNCNAME( STR )}, NULL },
{ "STRZERO", {HB_FS_PUBLIC}, {HB_FUNCNAME( STRZERO )}, NULL },
{ "MOD", {HB_FS_PUBLIC}, {HB_FUNCNAME( MOD )}, NULL },
{ "DELETEALLITEMS", {HB_FS_PUBLIC | HB_FS_MESSAGE}, {NULL}, NULL },
{ "ADDITEM", {HB_FS_PUBLIC | HB_FS_MESSAGE}, {NULL}, NULL },
{ "PQGETVALUE", {HB_FS_PUBLIC}, {HB_FUNCNAME( PQGETVALUE )}, NULL },
{ "ACTUALIZAR", {HB_FS_PUBLIC | HB_FS_LOCAL}, {HB_FUNCNAME( ACTUALIZAR )}, NULL },
{ "PQRESULTSTATUS", {HB_FS_PUBLIC}, {HB_FUNCNAME( PQRESULTSTATUS )}, NULL },
{ "X", {HB_FS_PUBLIC | HB_FS_MEMVAR}, {NULL}, NULL },
{ "VAL", {HB_FS_PUBLIC}, {HB_FUNCNAME( VAL )}, NULL },
{ "PQCLOSE", {HB_FS_PUBLIC}, {HB_FUNCNAME( PQCLOSE )}, NULL },
{ "RELEASE", {HB_FS_PUBLIC | HB_FS_MESSAGE}, {NULL}, NULL }
HB_INIT_SYMBOLS_EX_END( hb_vm_SymbolInit_DEMO_POSTGRES, "C:\\HARBOU~3\\contrib\\hbpgsql\\tests\\DEMO_P~1\\demo_postgres.prg", 0x0, 0x0002 )

#if defined(HB_PRAGMA_STARTUP)
   #pragma startup hb_vm_SymbolInit_DEMO_POSTGRES
#elif defined(HB_MSC_STARTUP)
   #if _MSC_VER >= 1010
      #pragma data_seg( ".CRT$XIY" )
      #pragma comment( linker, "/Merge:.CRT=.data" )
   #else
      #pragma data_seg( "XIY" )
   #endif
   static HB_$INITSYM hb_vm_auto_SymbolInit_DEMO_POSTGRES = hb_vm_SymbolInit_DEMO_POSTGRES;
   #pragma data_seg()
#endif

HB_FUNC( MAIN )
{
   static const BYTE pcode[] =
   {
	HB_P_FRAME, 5, 0,	/* locals, params */
/* 00003 */ HB_P_LINE, 39, 0,	/* 39 */
	HB_P_PUSHSTRSHORT, 10,	/* 10 */
	'l', 'o', 'c', 'a', 'l', 'h', 'o', 's', 't', 0, 
	HB_P_POPVARIABLE, 1, 0,	/* CSERVER */
/* 00021 */ HB_P_LINE, 40, 0,	/* 40 */
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	's', 'i', 's', 't', 'e', 'm', 'a', 0, 
	HB_P_POPVARIABLE, 2, 0,	/* CDATABASE */
/* 00037 */ HB_P_LINE, 41, 0,	/* 41 */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'b', 'r', 'u', 'n', 'o', 0, 
	HB_P_POPVARIABLE, 3, 0,	/* CUSER */
/* 00051 */ HB_P_LINE, 42, 0,	/* 42 */
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'g', 'n', 'u', 'l', 'i', 'n', 'u', 'x', 0, 
	HB_P_POPVARIABLE, 4, 0,	/* CPASS */
/* 00068 */ HB_P_LINE, 43, 0,	/* 43 */
	HB_P_PUSHSTRSHORT, 1,	/* 1 */
	0, 
	HB_P_POPVARIABLE, 5, 0,	/* CQUERY */
/* 00077 */ HB_P_LINE, 49, 0,	/* 49 */
	HB_P_PUSHFUNCSYM, 6, 0,	/* DEFINEWINDOW */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_PUSHSTRSHORT, 37,	/* 37 */
	'P', 'o', 's', 't', 'g', 'r', 'e', 's', ' ', 'O', 'O', 'H', 'G', ' ', '/', ' ', 'H', 'a', 'r', 'b', 'o', 'u', 'r', ' ', 'M', 'i', 'n', 'i', 'G', 'U', 'I', ' ', 'D', 'e', 'm', 'o', 0, 
	HB_P_ZERO,
	HB_P_ZERO,
	HB_P_PUSHINT, 128, 2,	/* 640 */
	HB_P_PUSHINT, 224, 1,	/* 480 */
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_TRUE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 65,
/* 00200 */ HB_P_LINE, 54, 0,	/* 54 */
	HB_P_MESSAGE, 7, 0,	/* DEFINE */
	HB_P_PUSHFUNCSYM, 8, 0,	/* _OOHG_SELECTSUBCLASS */
	HB_P_PUSHFUNCSYM, 9, 0,	/* TLABEL */
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'l', 'a', 'b', 'e', 'l', '_', '1', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 10,	/* 10 */
	HB_P_PUSHBYTE, 10,	/* 10 */
	HB_P_PUSHNIL,
	HB_P_PUSHINT, 44, 1,	/* 300 */
	HB_P_PUSHBYTE, 24,	/* 24 */
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'V', 'e', 'r', 'd', 'a', 'n', 'a', 0, 
	HB_P_PUSHBYTE, 12,	/* 12 */
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_TRUE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 31,
	HB_P_POP,
/* 00275 */ HB_P_LINE, 58, 0,	/* 58 */
	HB_P_MESSAGE, 7, 0,	/* DEFINE */
	HB_P_PUSHFUNCSYM, 8, 0,	/* _OOHG_SELECTSUBCLASS */
	HB_P_PUSHFUNCSYM, 9, 0,	/* TLABEL */
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'l', 'a', 'b', 'e', 'l', '_', '2', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 10,	/* 10 */
	HB_P_PUSHBYTE, 40,	/* 40 */
	HB_P_PUSHNIL,
	HB_P_PUSHINT, 44, 1,	/* 300 */
	HB_P_PUSHBYTE, 24,	/* 24 */
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'V', 'e', 'r', 'd', 'a', 'n', 'a', 0, 
	HB_P_PUSHBYTE, 12,	/* 12 */
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_TRUE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 31,
	HB_P_POP,
/* 00350 */ HB_P_LINE, 64, 0,	/* 64 */
	HB_P_PUSHFUNCSYM, 10, 0,	/* DEFINETEXTBOX */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'T', 'e', 'x', 't', '_', '2', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 30,	/* 30 */
	HB_P_PUSHBYTE, 80,	/* 80 */
	HB_P_PUSHINT, 44, 1,	/* 300 */
	HB_P_PUSHBYTE, 24,	/* 24 */
	HB_P_PUSHSTRSHORT, 1,	/* 1 */
	0, 
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'V', 'e', 'r', 'd', 'a', 'n', 'a', 0, 
	HB_P_PUSHBYTE, 12,	/* 12 */
	HB_P_PUSHSTRSHORT, 18,	/* 18 */
	'C', 'h', 'a', 'r', 'a', 'c', 't', 'e', 'r', ' ', 'T', 'e', 'x', 't', 'B', 'o', 'x', 0, 
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_DOSHORT, 41,
/* 00443 */ HB_P_LINE, 75, 0,	/* 75 */
	HB_P_MESSAGE, 7, 0,	/* DEFINE */
	HB_P_PUSHFUNCSYM, 8, 0,	/* _OOHG_SELECTSUBCLASS */
	HB_P_PUSHFUNCSYM, 11, 0,	/* TGRID */
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'G', 'r', 'i', 'd', '_', '1', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 30,	/* 30 */
	HB_P_PUSHBYTE, 120,	/* 120 */
	HB_P_PUSHINT, 244, 1,	/* 500 */
	HB_P_PUSHINT, 200, 0,	/* 200 */
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'c', 'o', 'd', 'e', 0, 
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'd', 'e', 'p', 't', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	' ', 'n', 'a', 'm', 'e', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	' ', 's', 'a', 'l', 'e', 's', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	's', 'a', 'l', 'a', 'r', 'y', 0, 
	HB_P_PUSHSTRSHORT, 10,	/* 10 */
	' ', 'c', 'r', 'e', 'a', 't', 'i', 'o', 'n', 0, 
	HB_P_ARRAYGEN, 6, 0,	/* 6 */
	HB_P_PUSHBYTE, 40,	/* 40 */
	HB_P_PUSHBYTE, 40,	/* 40 */
	HB_P_PUSHINT, 150, 0,	/* 150 */
	HB_P_PUSHBYTE, 40,	/* 40 */
	HB_P_PUSHBYTE, 70,	/* 70 */
	HB_P_PUSHBYTE, 100,	/* 100 */
	HB_P_ARRAYGEN, 6, 0,	/* 6 */
	HB_P_ARRAYGEN, 0, 0,	/* 0 */
	HB_P_ONE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHSTRSHORT, 22,	/* 22 */
	'E', 'd', 'i', 't', 'a', 'b', 'l', 'e', ' ', 'G', 'r', 'i', 'd', ' ', 'C', 'o', 'n', 't', 'r', 'o', 'l', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_ZERO,
	HB_P_ONE,
	HB_P_ONE,
	HB_P_ONE,
	HB_P_ONE,
	HB_P_ONE,
	HB_P_ARRAYGEN, 6, 0,	/* 6 */
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_TRUE,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 49,
	HB_P_POP,
/* 00628 */ HB_P_LINE, 80, 0,	/* 80 */
	HB_P_MESSAGE, 7, 0,	/* DEFINE */
	HB_P_PUSHFUNCSYM, 8, 0,	/* _OOHG_SELECTSUBCLASS */
	HB_P_PUSHFUNCSYM, 12, 0,	/* TBUTTON */
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'b', 'o', 't', '1', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 30,	/* 30 */
	HB_P_PUSHINT, 124, 1,	/* 380 */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'T', 'a', 'b', 'l', 'a', 0, 
	HB_P_PUSHBLOCKSHORT, 8,	/* 8 */
	HB_P_PUSHFUNCSYM, 13, 0,	/* TABLA */
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 31,
	HB_P_POP,
/* 00704 */ HB_P_LINE, 85, 0,	/* 85 */
	HB_P_MESSAGE, 7, 0,	/* DEFINE */
	HB_P_PUSHFUNCSYM, 8, 0,	/* _OOHG_SELECTSUBCLASS */
	HB_P_PUSHFUNCSYM, 12, 0,	/* TBUTTON */
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'b', 'o', 't', '2', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHBYTE, 100,	/* 100 */
	HB_P_PUSHINT, 124, 1,	/* 380 */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'L', 'l', 'e', 'n', 'a', 'r', 0, 
	HB_P_PUSHBLOCKSHORT, 8,	/* 8 */
	HB_P_PUSHFUNCSYM, 14, 0,	/* INSERTA */
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 31,
	HB_P_POP,
/* 00781 */ HB_P_LINE, 90, 0,	/* 90 */
	HB_P_MESSAGE, 7, 0,	/* DEFINE */
	HB_P_PUSHFUNCSYM, 8, 0,	/* _OOHG_SELECTSUBCLASS */
	HB_P_PUSHFUNCSYM, 12, 0,	/* TBUTTON */
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'b', 'o', 't', '3', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHINT, 170, 0,	/* 170 */
	HB_P_PUSHINT, 124, 1,	/* 380 */
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'L', 'e', 'e', 'r', 0, 
	HB_P_PUSHBLOCKSHORT, 8,	/* 8 */
	HB_P_PUSHFUNCSYM, 15, 0,	/* LEER */
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 31,
	HB_P_POP,
/* 00857 */ HB_P_LINE, 95, 0,	/* 95 */
	HB_P_MESSAGE, 7, 0,	/* DEFINE */
	HB_P_PUSHFUNCSYM, 8, 0,	/* _OOHG_SELECTSUBCLASS */
	HB_P_PUSHFUNCSYM, 12, 0,	/* TBUTTON */
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'b', 'o', 't', '4', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHINT, 240, 0,	/* 240 */
	HB_P_PUSHINT, 124, 1,	/* 380 */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'B', 'o', 'r', 'r', 'a', 'r', 0, 
	HB_P_PUSHBLOCKSHORT, 8,	/* 8 */
	HB_P_PUSHFUNCSYM, 16, 0,	/* BORRAR */
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 31,
	HB_P_POP,
/* 00935 */ HB_P_LINE, 100, 0,	/* 100 */
	HB_P_MESSAGE, 7, 0,	/* DEFINE */
	HB_P_PUSHFUNCSYM, 8, 0,	/* _OOHG_SELECTSUBCLASS */
	HB_P_PUSHFUNCSYM, 12, 0,	/* TBUTTON */
	HB_P_FUNCTIONSHORT, 0,
	HB_P_PUSHNIL,
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 5,	/* 5 */
	'b', 'o', 't', '5', 0, 
	HB_P_PUSHNIL,
	HB_P_PUSHINT, 54, 1,	/* 310 */
	HB_P_PUSHINT, 124, 1,	/* 380 */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'S', 'a', 'l', 'i', 'r', 0, 
	HB_P_PUSHBLOCKSHORT, 8,	/* 8 */
	HB_P_PUSHFUNCSYM, 17, 0,	/* TERMINAR */
	HB_P_FUNCTIONSHORT, 0,
	HB_P_ENDBLOCK,
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_PUSHNIL,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_FALSE,
	HB_P_PUSHNIL,
	HB_P_SENDSHORT, 31,
	HB_P_POP,
/* 01012 */ HB_P_LINE, 102, 0,	/* 102 */
	HB_P_PUSHFUNCSYM, 18, 0,	/* _ENDWINDOW */
	HB_P_DOSHORT, 0,
/* 01020 */ HB_P_LINE, 104, 0,	/* 104 */
	HB_P_MESSAGE, 19, 0,	/* CENTER */
	HB_P_PUSHFUNCSYM, 20, 0,	/* GETEXISTINGFORMOBJECT */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 1,
	HB_P_SENDSHORT, 0,
	HB_P_POP,
/* 01043 */ HB_P_LINE, 106, 0,	/* 106 */
	HB_P_MESSAGE, 21, 0,	/* ACTIVATE */
	HB_P_PUSHFUNCSYM, 20, 0,	/* GETEXISTINGFORMOBJECT */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 1,
	HB_P_SENDSHORT, 0,
	HB_P_POP,
/* 01066 */ HB_P_LINE, 108, 0,	/* 108 */
	HB_P_ENDPROC
/* 01070 */
   };

   hb_vmExecute( pcode, symbols );
}

HB_FUNC( TABLA )
{
   static const BYTE pcode[] =
   {
/* 00000 */ HB_P_LINE, 115, 0,	/* 115 */
	HB_P_MESSAGE, 22, 0,	/* _VALUE */
	HB_P_PUSHFUNCSYM, 23, 0,	/* GETEXISTINGCONTROLOBJECT */
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'l', 'a', 'b', 'e', 'l', '_', '1', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 15,	/* 15 */
	'C', 'o', 'n', 'n', 'e', 'c', 't', 'i', 'n', 'g', '.', '.', '.', '.', 0, 
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00050 */ HB_P_LINE, 117, 0,	/* 117 */
	HB_P_PUSHFUNCSYM, 24, 0,	/* PQCONNECT */
	HB_P_PUSHVARIABLE, 2, 0,	/* CDATABASE */
	HB_P_PUSHVARIABLE, 1, 0,	/* CSERVER */
	HB_P_PUSHVARIABLE, 3, 0,	/* CUSER */
	HB_P_PUSHVARIABLE, 4, 0,	/* CPASS */
	HB_P_PUSHINT, 56, 21,	/* 5432 */
	HB_P_FUNCTIONSHORT, 5,
	HB_P_POPVARIABLE, 25, 0,	/* CONN */
/* 00076 */ HB_P_LINE, 119, 0,	/* 119 */
	HB_P_PUSHFUNCSYM, 26, 0,	/* PQSTATUS */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_ZERO,
	HB_P_NOTEQUAL,
	HB_P_JUMPFALSENEAR, 66,	/* 66 (abs: 00155) */
/* 00091 */ HB_P_LINE, 120, 0,	/* 120 */
	HB_P_PUSHFUNCSYM, 27, 0,	/* MSGINFO */
	HB_P_PUSHSTRSHORT, 42,	/* 42 */
	'N', 'o', ' ', 's', 'e', ' ', 'p', 'u', 'd', 'o', ' ', 'c', 'o', 'n', 'e', 'c', 't', 'a', 'r', ' ', 'c', 'o', 'n', ' ', 'l', 'a', ' ', 'b', 'a', 's', 'e', ' ', 'd', 'e', ' ', 'd', 'a', 't', 'o', 's', ' ', 0, 
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'E', 'r', 'r', 'o', 'r', 0, 
	HB_P_DOSHORT, 2,
/* 00151 */ HB_P_LINE, 121, 0,	/* 121 */
	HB_P_ENDPROC,
/* 00155 */ HB_P_LINE, 124, 0,	/* 124 */
	HB_P_MESSAGE, 22, 0,	/* _VALUE */
	HB_P_PUSHFUNCSYM, 23, 0,	/* GETEXISTINGCONTROLOBJECT */
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'l', 'a', 'b', 'e', 'l', '_', '1', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 18,	/* 18 */
	'D', 'r', 'o', 'p', 'p', 'i', 'n', 'g', ' ', 't', 'a', 'b', 'l', 'e', '.', '.', '.', 0, 
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00208 */ HB_P_LINE, 126, 0,	/* 126 */
	HB_P_PUSHFUNCSYM, 28, 0,	/* PQEXEC */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_PUSHSTRSHORT, 16,	/* 16 */
	'D', 'R', 'O', 'P', ' ', 'T', 'A', 'B', 'L', 'E', ' ', 't', 'e', 's', 't', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_POPVARIABLE, 29, 0,	/* RES */
/* 00240 */ HB_P_LINE, 127, 0,	/* 127 */
	HB_P_PUSHFUNCSYM, 30, 0,	/* PQCLEAR */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_DOSHORT, 1,
/* 00251 */ HB_P_LINE, 129, 0,	/* 129 */
	HB_P_MESSAGE, 22, 0,	/* _VALUE */
	HB_P_PUSHFUNCSYM, 23, 0,	/* GETEXISTINGCONTROLOBJECT */
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'l', 'a', 'b', 'e', 'l', '_', '2', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 23,	/* 23 */
	'C', 'r', 'e', 'a', 't', 'i', 'n', 'g', ' ', 't', 'e', 's', 't', ' ', 't', 'a', 'b', 'l', 'e', '.', '.', '.', 0, 
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00309 */ HB_P_LINE, 130, 0,	/* 130 */
	HB_P_PUSHSTRSHORT, 19,	/* 19 */
	'C', 'R', 'E', 'A', 'T', 'E', ' ', 'T', 'A', 'B', 'L', 'E', ' ', 't', 'e', 's', 't', '(', 0, 
	HB_P_POPVARIABLE, 5, 0,	/* CQUERY */
/* 00336 */ HB_P_LINE, 131, 0,	/* 131 */
	HB_P_PUSHVARIABLE, 5, 0,	/* CQUERY */
	HB_P_PUSHSTRSHORT, 41,	/* 41 */
	' ', ' ', ' ', ' ', ' ', 'C', 'o', 'd', 'e', ' ', 'i', 'n', 't', 'e', 'g', 'e', 'r', ' ', 'n', 'o', 't', ' ', 'n', 'u', 'l', 'l', ' ', 'p', 'r', 'i', 'm', 'a', 'r', 'y', ' ', 'k', 'e', 'y', ',', ' ', 0, 
	HB_P_PLUS,
	HB_P_POPVARIABLE, 5, 0,	/* CQUERY */
/* 00389 */ HB_P_LINE, 132, 0,	/* 132 */
	HB_P_PUSHVARIABLE, 5, 0,	/* CQUERY */
	HB_P_PUSHSTRSHORT, 20,	/* 20 */
	' ', ' ', ' ', ' ', ' ', 'd', 'e', 'p', 't', ' ', 'I', 'n', 't', 'e', 'g', 'e', 'r', ',', ' ', 0, 
	HB_P_PLUS,
	HB_P_POPVARIABLE, 5, 0,	/* CQUERY */
/* 00421 */ HB_P_LINE, 133, 0,	/* 133 */
	HB_P_PUSHVARIABLE, 5, 0,	/* CQUERY */
	HB_P_PUSHSTRSHORT, 24,	/* 24 */
	' ', ' ', ' ', ' ', ' ', 'N', 'a', 'm', 'e', ' ', 'V', 'a', 'r', 'c', 'h', 'a', 'r', '(', '4', '0', ')', ',', ' ', 0, 
	HB_P_PLUS,
	HB_P_POPVARIABLE, 5, 0,	/* CQUERY */
/* 00457 */ HB_P_LINE, 134, 0,	/* 134 */
	HB_P_PUSHVARIABLE, 5, 0,	/* CQUERY */
	HB_P_PUSHSTRSHORT, 21,	/* 21 */
	' ', ' ', ' ', ' ', ' ', 'S', 'a', 'l', 'e', 's', ' ', 'b', 'o', 'o', 'l', 'e', 'a', 'n', ',', ' ', 0, 
	HB_P_PLUS,
	HB_P_POPVARIABLE, 5, 0,	/* CQUERY */
/* 00490 */ HB_P_LINE, 135, 0,	/* 135 */
	HB_P_PUSHVARIABLE, 5, 0,	/* CQUERY */
	HB_P_PUSHSTRSHORT, 18,	/* 18 */
	' ', ' ', ' ', ' ', ' ', 'T', 'a', 'x', ' ', 'F', 'l', 'o', 'a', 't', '4', ',', ' ', 0, 
	HB_P_PLUS,
	HB_P_POPVARIABLE, 5, 0,	/* CQUERY */
/* 00520 */ HB_P_LINE, 136, 0,	/* 136 */
	HB_P_PUSHVARIABLE, 5, 0,	/* CQUERY */
	HB_P_PUSHSTRSHORT, 31,	/* 31 */
	' ', ' ', ' ', ' ', ' ', 'S', 'a', 'l', 'a', 'r', 'y', ' ', 'D', 'o', 'u', 'b', 'l', 'e', ' ', 'P', 'r', 'e', 'c', 'i', 's', 'i', 'o', 'n', ',', ' ', 0, 
	HB_P_PLUS,
	HB_P_POPVARIABLE, 5, 0,	/* CQUERY */
/* 00563 */ HB_P_LINE, 137, 0,	/* 137 */
	HB_P_PUSHVARIABLE, 5, 0,	/* CQUERY */
	HB_P_PUSHSTRSHORT, 28,	/* 28 */
	' ', ' ', ' ', ' ', ' ', 'B', 'u', 'd', 'g', 'e', 't', ' ', 'N', 'u', 'm', 'e', 'r', 'i', 'c', '(', '1', '2', ',', '2', ')', ',', ' ', 0, 
	HB_P_PLUS,
	HB_P_POPVARIABLE, 5, 0,	/* CQUERY */
/* 00603 */ HB_P_LINE, 138, 0,	/* 138 */
	HB_P_PUSHVARIABLE, 5, 0,	/* CQUERY */
	HB_P_PUSHSTRSHORT, 30,	/* 30 */
	' ', ' ', ' ', ' ', ' ', 'D', 'i', 's', 'c', 'o', 'u', 'n', 't', ' ', 'N', 'u', 'm', 'e', 'r', 'i', 'c', ' ', '(', '5', ',', '2', ')', ',', ' ', 0, 
	HB_P_PLUS,
	HB_P_POPVARIABLE, 5, 0,	/* CQUERY */
/* 00645 */ HB_P_LINE, 139, 0,	/* 139 */
	HB_P_PUSHVARIABLE, 5, 0,	/* CQUERY */
	HB_P_PUSHSTRSHORT, 21,	/* 21 */
	' ', ' ', ' ', ' ', ' ', 'C', 'r', 'e', 'a', 't', 'i', 'o', 'n', ' ', 'D', 'a', 't', 'e', ',', ' ', 0, 
	HB_P_PLUS,
	HB_P_POPVARIABLE, 5, 0,	/* CQUERY */
/* 00678 */ HB_P_LINE, 140, 0,	/* 140 */
	HB_P_PUSHVARIABLE, 5, 0,	/* CQUERY */
	HB_P_PUSHSTRSHORT, 25,	/* 25 */
	' ', ' ', ' ', ' ', ' ', 'D', 'e', 's', 'c', 'r', 'i', 'p', 't', 'i', 'o', 'n', ' ', 't', 'e', 'x', 't', ' ', ')', ' ', 0, 
	HB_P_PLUS,
	HB_P_POPVARIABLE, 5, 0,	/* CQUERY */
/* 00715 */ HB_P_LINE, 142, 0,	/* 142 */
	HB_P_PUSHFUNCSYM, 28, 0,	/* PQEXEC */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_PUSHVARIABLE, 5, 0,	/* CQUERY */
	HB_P_FUNCTIONSHORT, 2,
	HB_P_POPVARIABLE, 29, 0,	/* RES */
/* 00732 */ HB_P_LINE, 143, 0,	/* 143 */
	HB_P_PUSHFUNCSYM, 30, 0,	/* PQCLEAR */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_DOSHORT, 1,
/* 00743 */ HB_P_LINE, 145, 0,	/* 145 */
	HB_P_PUSHFUNCSYM, 28, 0,	/* PQEXEC */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_PUSHSTRSHORT, 59,	/* 59 */
	'S', 'E', 'L', 'E', 'C', 'T', ' ', 'c', 'o', 'd', 'e', ',', ' ', 'd', 'e', 'p', 't', ',', ' ', 'n', 'a', 'm', 'e', ',', ' ', 's', 'a', 'l', 'e', 's', ',', ' ', 's', 'a', 'l', 'a', 'r', 'y', ',', ' ', 'c', 'r', 'e', 'a', 't', 'i', 'o', 'n', ' ', 'F', 'R', 'O', 'M', ' ', 't', 'e', 's', 't', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_POPVARIABLE, 29, 0,	/* RES */
/* 00818 */ HB_P_LINE, 146, 0,	/* 146 */
	HB_P_PUSHFUNCSYM, 30, 0,	/* PQCLEAR */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_DOSHORT, 1,
/* 00829 */ HB_P_LINE, 148, 0,	/* 148 */
	HB_P_PUSHFUNCSYM, 28, 0,	/* PQEXEC */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'B', 'E', 'G', 'I', 'N', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_POPVARIABLE, 29, 0,	/* RES */
/* 00851 */ HB_P_LINE, 149, 0,	/* 149 */
	HB_P_PUSHFUNCSYM, 30, 0,	/* PQCLEAR */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_DOSHORT, 1,
/* 00862 */ HB_P_LINE, 150, 0,	/* 150 */
	HB_P_PUSHFUNCSYM, 27, 0,	/* MSGINFO */
	HB_P_PUSHSTRSHORT, 28,	/* 28 */
	'T', 'a', 'b', 'l', 'a', ' ', 'c', 'o', 'r', 'r', 'e', 'c', 't', 'a', 'm', 'e', 'n', 't', 'e', ' ', 'c', 'r', 'e', 'a', 'd', 'a', ' ', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'O', 'k', 0, 
	HB_P_DOSHORT, 2,
	HB_P_ENDPROC
/* 00906 */
   };

   hb_vmExecute( pcode, symbols );
}

HB_FUNC( INSERTA )
{
   static const BYTE pcode[] =
   {
/* 00000 */ HB_P_LINE, 157, 0,	/* 157 */
	HB_P_PUSHFUNCSYM, 24, 0,	/* PQCONNECT */
	HB_P_PUSHVARIABLE, 2, 0,	/* CDATABASE */
	HB_P_PUSHVARIABLE, 1, 0,	/* CSERVER */
	HB_P_PUSHVARIABLE, 3, 0,	/* CUSER */
	HB_P_PUSHVARIABLE, 4, 0,	/* CPASS */
	HB_P_PUSHINT, 56, 21,	/* 5432 */
	HB_P_FUNCTIONSHORT, 5,
	HB_P_POPVARIABLE, 25, 0,	/* CONN */
/* 00026 */ HB_P_LINE, 159, 0,	/* 159 */
	HB_P_ONE,
	HB_P_PUSHUNREF,
	HB_P_POPVARIABLE, 31, 0,	/* I */
	HB_P_JUMP, 222, 1,	/* 478 (abs: 00512) */
/* 00037 */ HB_P_LINE, 161, 0,	/* 161 */
	HB_P_MESSAGE, 22, 0,	/* _VALUE */
	HB_P_PUSHFUNCSYM, 23, 0,	/* GETEXISTINGCONTROLOBJECT */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	't', 'e', 'x', 't', '_', '2', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 21,	/* 21 */
	'I', 'n', 's', 'e', 'r', 't', 'i', 'n', 'g', ' ', 'v', 'a', 'l', 'u', 'e', 's', '.', '.', '.', '.', 0, 
	HB_P_PUSHFUNCSYM, 32, 0,	/* STR */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_PLUS,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00101 */ HB_P_LINE, 163, 0,	/* 163 */
	HB_P_PUSHSTRSHORT, 61,	/* 61 */
	'I', 'N', 'S', 'E', 'R', 'T', ' ', 'I', 'N', 'T', 'O', ' ', 't', 'e', 's', 't', '(', 'c', 'o', 'd', 'e', ',', ' ', 'd', 'e', 'p', 't', ',', ' ', 'n', 'a', 'm', 'e', ',', ' ', 's', 'a', 'l', 'e', 's', ',', ' ', 's', 'a', 'l', 'a', 'r', 'y', ',', ' ', 'c', 'r', 'e', 'a', 't', 'i', 'o', 'n', ')', ' ', 0, 
	HB_P_POPVARIABLE, 5, 0,	/* CQUERY */
/* 00170 */ HB_P_LINE, 164, 0,	/* 164 */
	HB_P_PUSHVARIABLE, 5, 0,	/* CQUERY */
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	'V', 'A', 'L', 'U', 'E', 'S', '(', ' ', 0, 
	HB_P_PUSHFUNCSYM, 32, 0,	/* STR */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_PLUS,
	HB_P_PUSHSTRSHORT, 2,	/* 2 */
	',', 0, 
	HB_P_PLUS,
	HB_P_PUSHFUNCSYM, 32, 0,	/* STR */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_ONE,
	HB_P_PLUS,
	HB_P_FUNCTIONSHORT, 1,
	HB_P_PLUS,
	HB_P_PUSHSTRSHORT, 20,	/* 20 */
	',', ' ', 39, 'D', 'E', 'P', 'A', 'R', 'T', 'M', 'E', 'N', 'T', ' ', 'N', 'A', 'M', 'E', ' ', 0, 
	HB_P_PLUS,
	HB_P_PUSHFUNCSYM, 33, 0,	/* STRZERO */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_PLUS,
	HB_P_PUSHSTRSHORT, 9,	/* 9 */
	39, ',', ' ', 39, 'y', 39, ',', ' ', 0, 
	HB_P_PLUS,
	HB_P_PUSHFUNCSYM, 32, 0,	/* STR */
	HB_P_PUSHDOUBLE, 164, 112, 61, 10, 215, 199, 114, 64, 10, 2,	/* 300.49, 10, 2 */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_PLUS,
	HB_P_FUNCTIONSHORT, 1,
	HB_P_PLUS,
	HB_P_PUSHSTRSHORT, 17,	/* 17 */
	',', ' ', 39, '2', '0', '0', '3', '-', '1', '2', '-', '2', '8', 39, ' ', ')', 0, 
	HB_P_PLUS,
	HB_P_PLUS,
	HB_P_POPVARIABLE, 5, 0,	/* CQUERY */
/* 00301 */ HB_P_LINE, 166, 0,	/* 166 */
	HB_P_PUSHFUNCSYM, 28, 0,	/* PQEXEC */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_PUSHVARIABLE, 5, 0,	/* CQUERY */
	HB_P_FUNCTIONSHORT, 2,
	HB_P_POPVARIABLE, 29, 0,	/* RES */
/* 00318 */ HB_P_LINE, 167, 0,	/* 167 */
	HB_P_PUSHFUNCSYM, 30, 0,	/* PQCLEAR */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_DOSHORT, 1,
/* 00329 */ HB_P_LINE, 169, 0,	/* 169 */
	HB_P_PUSHFUNCSYM, 34, 0,	/* MOD */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_PUSHBYTE, 100,	/* 100 */
	HB_P_FUNCTIONSHORT, 2,
	HB_P_ZERO,
	HB_P_EXACTLYEQUAL,
	HB_P_JUMPFALSE, 157, 0,	/* 157 (abs: 00501) */
/* 00347 */ HB_P_LINE, 170, 0,	/* 170 */
	HB_P_MESSAGE, 22, 0,	/* _VALUE */
	HB_P_PUSHFUNCSYM, 23, 0,	/* GETEXISTINGCONTROLOBJECT */
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'l', 'a', 'b', 'e', 'l', '_', '1', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHFUNCSYM, 28, 0,	/* PQEXEC */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'C', 'O', 'M', 'M', 'I', 'T', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00397 */ HB_P_LINE, 171, 0,	/* 171 */
	HB_P_MESSAGE, 22, 0,	/* _VALUE */
	HB_P_PUSHFUNCSYM, 23, 0,	/* GETEXISTINGCONTROLOBJECT */
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'l', 'a', 'b', 'e', 'l', '_', '2', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHFUNCSYM, 30, 0,	/* PQCLEAR */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00438 */ HB_P_LINE, 173, 0,	/* 173 */
	HB_P_PUSHFUNCSYM, 28, 0,	/* PQEXEC */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'B', 'E', 'G', 'I', 'N', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_POPVARIABLE, 29, 0,	/* RES */
/* 00460 */ HB_P_LINE, 174, 0,	/* 174 */
	HB_P_MESSAGE, 22, 0,	/* _VALUE */
	HB_P_PUSHFUNCSYM, 23, 0,	/* GETEXISTINGCONTROLOBJECT */
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'l', 'a', 'b', 'e', 'l', '_', '2', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHFUNCSYM, 30, 0,	/* PQCLEAR */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00501 */ HB_P_LINE, 159, 0,	/* 159 */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_INC,
	HB_P_DUPLICATE,
	HB_P_POPVARIABLE, 31, 0,	/* I */
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_GREATER,
	HB_P_JUMPFALSE, 34, 254,	/* -478 (abs: 00037) */
/* 00518 */ HB_P_LINE, 178, 0,	/* 178 */
	HB_P_PUSHFUNCSYM, 27, 0,	/* MSGINFO */
	HB_P_PUSHSTRSHORT, 29,	/* 29 */
	'T', 'a', 'b', 'l', 'a', ' ', 'c', 'o', 'r', 'r', 'e', 'c', 't', 'a', 'm', 'e', 'n', 't', 'e', ' ', 'l', 'l', 'e', 'n', 'a', 'd', 'a', ' ', 0, 
	HB_P_PUSHSTRSHORT, 3,	/* 3 */
	'O', 'k', 0, 
	HB_P_DOSHORT, 2,
/* 00562 */ HB_P_LINE, 179, 0,	/* 179 */
	HB_P_ENDPROC
/* 00566 */
   };

   hb_vmExecute( pcode, symbols );
}

HB_FUNC( BORRAR )
{
   static const BYTE pcode[] =
   {
/* 00000 */ HB_P_LINE, 186, 0,	/* 186 */
	HB_P_PUSHFUNCSYM, 24, 0,	/* PQCONNECT */
	HB_P_PUSHVARIABLE, 2, 0,	/* CDATABASE */
	HB_P_PUSHVARIABLE, 1, 0,	/* CSERVER */
	HB_P_PUSHVARIABLE, 3, 0,	/* CUSER */
	HB_P_PUSHVARIABLE, 4, 0,	/* CPASS */
	HB_P_PUSHINT, 56, 21,	/* 5432 */
	HB_P_FUNCTIONSHORT, 5,
	HB_P_POPVARIABLE, 25, 0,	/* CONN */
/* 00026 */ HB_P_LINE, 188, 0,	/* 188 */
	HB_P_ONE,
	HB_P_PUSHUNREF,
	HB_P_POPVARIABLE, 31, 0,	/* I */
	HB_P_JUMP, 237, 0,	/* 237 (abs: 00271) */
/* 00037 */ HB_P_LINE, 189, 0,	/* 189 */
	HB_P_MESSAGE, 22, 0,	/* _VALUE */
	HB_P_PUSHFUNCSYM, 23, 0,	/* GETEXISTINGCONTROLOBJECT */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	't', 'e', 'x', 't', '_', '2', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 20,	/* 20 */
	'D', 'e', 'l', 'e', 't', 'i', 'n', 'g', ' ', 'v', 'a', 'l', 'u', 'e', 's', '.', '.', '.', '.', 0, 
	HB_P_PUSHFUNCSYM, 32, 0,	/* STR */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_PLUS,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00100 */ HB_P_LINE, 191, 0,	/* 191 */
	HB_P_PUSHSTRSHORT, 31,	/* 31 */
	'D', 'E', 'L', 'E', 'T', 'E', ' ', 'F', 'R', 'O', 'M', ' ', 't', 'e', 's', 't', ' ', 'W', 'H', 'E', 'R', 'E', ' ', 'c', 'o', 'd', 'e', ' ', '=', ' ', 0, 
	HB_P_PUSHFUNCSYM, 32, 0,	/* STR */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_PLUS,
	HB_P_POPVARIABLE, 5, 0,	/* CQUERY */
/* 00148 */ HB_P_LINE, 192, 0,	/* 192 */
	HB_P_PUSHFUNCSYM, 28, 0,	/* PQEXEC */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_PUSHVARIABLE, 5, 0,	/* CQUERY */
	HB_P_FUNCTIONSHORT, 2,
	HB_P_POPVARIABLE, 29, 0,	/* RES */
/* 00165 */ HB_P_LINE, 193, 0,	/* 193 */
	HB_P_PUSHFUNCSYM, 30, 0,	/* PQCLEAR */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_DOSHORT, 1,
/* 00176 */ HB_P_LINE, 195, 0,	/* 195 */
	HB_P_PUSHFUNCSYM, 34, 0,	/* MOD */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_PUSHBYTE, 100,	/* 100 */
	HB_P_FUNCTIONSHORT, 2,
	HB_P_ZERO,
	HB_P_EXACTLYEQUAL,
	HB_P_JUMPFALSENEAR, 69,	/* 69 (abs: 00260) */
/* 00193 */ HB_P_LINE, 196, 0,	/* 196 */
	HB_P_PUSHFUNCSYM, 28, 0,	/* PQEXEC */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'C', 'O', 'M', 'M', 'I', 'T', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_POPVARIABLE, 29, 0,	/* RES */
/* 00216 */ HB_P_LINE, 197, 0,	/* 197 */
	HB_P_PUSHFUNCSYM, 30, 0,	/* PQCLEAR */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_DOSHORT, 1,
/* 00227 */ HB_P_LINE, 199, 0,	/* 199 */
	HB_P_PUSHFUNCSYM, 28, 0,	/* PQEXEC */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'B', 'E', 'G', 'I', 'N', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_POPVARIABLE, 29, 0,	/* RES */
/* 00249 */ HB_P_LINE, 200, 0,	/* 200 */
	HB_P_PUSHFUNCSYM, 30, 0,	/* PQCLEAR */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_DOSHORT, 1,
/* 00260 */ HB_P_LINE, 188, 0,	/* 188 */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_INC,
	HB_P_DUPLICATE,
	HB_P_POPVARIABLE, 31, 0,	/* I */
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_GREATER,
	HB_P_JUMPFALSE, 19, 255,	/* -237 (abs: 00037) */
/* 00277 */ HB_P_LINE, 203, 0,	/* 203 */
	HB_P_MESSAGE, 35, 0,	/* DELETEALLITEMS */
	HB_P_PUSHFUNCSYM, 23, 0,	/* GETEXISTINGCONTROLOBJECT */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'g', 'r', 'i', 'd', '_', '1', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_SENDSHORT, 0,
	HB_P_POP,
/* 00309 */ HB_P_LINE, 204, 0,	/* 204 */
	HB_P_ENDPROC
/* 00313 */
   };

   hb_vmExecute( pcode, symbols );
}

HB_FUNC( LEER )
{
   static const BYTE pcode[] =
   {
/* 00000 */ HB_P_LINE, 210, 0,	/* 210 */
	HB_P_PUSHFUNCSYM, 24, 0,	/* PQCONNECT */
	HB_P_PUSHVARIABLE, 2, 0,	/* CDATABASE */
	HB_P_PUSHVARIABLE, 1, 0,	/* CSERVER */
	HB_P_PUSHVARIABLE, 3, 0,	/* CUSER */
	HB_P_PUSHVARIABLE, 4, 0,	/* CPASS */
	HB_P_PUSHINT, 56, 21,	/* 5432 */
	HB_P_FUNCTIONSHORT, 5,
	HB_P_POPVARIABLE, 25, 0,	/* CONN */
/* 00026 */ HB_P_LINE, 212, 0,	/* 212 */
	HB_P_ONE,
	HB_P_PUSHUNREF,
	HB_P_POPVARIABLE, 31, 0,	/* I */
	HB_P_JUMP, 27, 1,	/* 283 (abs: 00317) */
/* 00037 */ HB_P_LINE, 214, 0,	/* 214 */
	HB_P_MESSAGE, 22, 0,	/* _VALUE */
	HB_P_PUSHFUNCSYM, 23, 0,	/* GETEXISTINGCONTROLOBJECT */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	't', 'e', 'x', 't', '_', '2', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 19,	/* 19 */
	'R', 'e', 'a', 'd', 'i', 'n', 'g', ' ', 'v', 'a', 'l', 'u', 'e', 's', '.', '.', '.', '.', 0, 
	HB_P_PUSHFUNCSYM, 32, 0,	/* STR */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_PLUS,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00099 */ HB_P_LINE, 216, 0,	/* 216 */
	HB_P_PUSHSTRSHORT, 59,	/* 59 */
	'S', 'E', 'L', 'E', 'C', 'T', ' ', 'c', 'o', 'd', 'e', ',', ' ', 'd', 'e', 'p', 't', ',', ' ', 'n', 'a', 'm', 'e', ',', ' ', 's', 'a', 'l', 'e', 's', ',', ' ', 's', 'a', 'l', 'a', 'r', 'y', ',', ' ', 'c', 'r', 'e', 'a', 't', 'i', 'o', 'n', ' ', 'F', 'R', 'O', 'M', ' ', 't', 'e', 's', 't', 0, 
	HB_P_POPVARIABLE, 5, 0,	/* CQUERY */
/* 00166 */ HB_P_LINE, 218, 0,	/* 218 */
	HB_P_PUSHFUNCSYM, 28, 0,	/* PQEXEC */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_PUSHVARIABLE, 5, 0,	/* CQUERY */
	HB_P_FUNCTIONSHORT, 2,
	HB_P_POPVARIABLE, 29, 0,	/* RES */
/* 00183 */ HB_P_LINE, 220, 0,	/* 220 */
	HB_P_MESSAGE, 36, 0,	/* ADDITEM */
	HB_P_PUSHFUNCSYM, 23, 0,	/* GETEXISTINGCONTROLOBJECT */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'g', 'r', 'i', 'd', '_', '1', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHFUNCSYM, 37, 0,	/* PQGETVALUE */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_ONE,
	HB_P_FUNCTIONSHORT, 3,
	HB_P_PUSHFUNCSYM, 37, 0,	/* PQGETVALUE */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_FUNCTIONSHORT, 3,
	HB_P_PUSHFUNCSYM, 37, 0,	/* PQGETVALUE */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_PUSHBYTE, 3,	/* 3 */
	HB_P_FUNCTIONSHORT, 3,
	HB_P_PUSHFUNCSYM, 37, 0,	/* PQGETVALUE */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_PUSHBYTE, 4,	/* 4 */
	HB_P_FUNCTIONSHORT, 3,
	HB_P_PUSHFUNCSYM, 37, 0,	/* PQGETVALUE */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_PUSHBYTE, 5,	/* 5 */
	HB_P_FUNCTIONSHORT, 3,
	HB_P_PUSHFUNCSYM, 37, 0,	/* PQGETVALUE */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_PUSHBYTE, 6,	/* 6 */
	HB_P_FUNCTIONSHORT, 3,
	HB_P_ARRAYGEN, 6, 0,	/* 6 */
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00295 */ HB_P_LINE, 222, 0,	/* 222 */
	HB_P_PUSHFUNCSYM, 30, 0,	/* PQCLEAR */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_DOSHORT, 1,
/* 00306 */ HB_P_LINE, 212, 0,	/* 212 */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_INC,
	HB_P_DUPLICATE,
	HB_P_POPVARIABLE, 31, 0,	/* I */
	HB_P_PUSHBYTE, 50,	/* 50 */
	HB_P_GREATER,
	HB_P_JUMPFALSE, 229, 254,	/* -283 (abs: 00037) */
/* 00323 */ HB_P_LINE, 225, 0,	/* 225 */
	HB_P_PUSHFUNCSYM, 27, 0,	/* MSGINFO */
	HB_P_PUSHSTRSHORT, 26,	/* 26 */
	'T', 'a', 'b', 'l', 'a', ' ', 'c', 'o', 'r', 'r', 'e', 'c', 't', 'a', 'm', 'e', 'n', 't', 'e', ' ', 'l', 'e', 'i', 'd', 'a', 0, 
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'L', 'e', 'c', 't', 'u', 'r', 'a', 0, 
	HB_P_DOSHORT, 2,
/* 00369 */ HB_P_LINE, 226, 0,	/* 226 */
	HB_P_ENDPROC
/* 00373 */
   };

   hb_vmExecute( pcode, symbols );
}

HB_FUNC( ACTUALIZAR )
{
   static const BYTE pcode[] =
   {
/* 00000 */ HB_P_LINE, 234, 0,	/* 234 */
	HB_P_ONE,
	HB_P_PUSHUNREF,
	HB_P_POPVARIABLE, 31, 0,	/* I */
	HB_P_JUMP, 254, 0,	/* 254 (abs: 00262) */
/* 00011 */ HB_P_LINE, 235, 0,	/* 235 */
	HB_P_MESSAGE, 22, 0,	/* _VALUE */
	HB_P_PUSHFUNCSYM, 23, 0,	/* GETEXISTINGCONTROLOBJECT */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	't', 'e', 'x', 't', '_', '2', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 20,	/* 20 */
	'U', 'p', 'd', 'a', 't', 'i', 'n', 'g', ' ', 'v', 'a', 'l', 'u', 'e', 's', '.', '.', '.', '.', 0, 
	HB_P_PUSHFUNCSYM, 32, 0,	/* STR */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_PLUS,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00074 */ HB_P_LINE, 237, 0,	/* 237 */
	HB_P_PUSHSTRSHORT, 48,	/* 48 */
	'U', 'P', 'D', 'A', 'T', 'E', ' ', 'F', 'R', 'O', 'M', ' ', 't', 'e', 's', 't', ' ', 'S', 'E', 'T', ' ', 's', 'a', 'l', 'a', 'r', 'y', ' ', '=', ' ', '4', '0', '0', ' ', 'W', 'H', 'E', 'R', 'E', ' ', 'c', 'o', 'd', 'e', ' ', '=', ' ', 0, 
	HB_P_PUSHFUNCSYM, 32, 0,	/* STR */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_PLUS,
	HB_P_POPVARIABLE, 5, 0,	/* CQUERY */
/* 00139 */ HB_P_LINE, 238, 0,	/* 238 */
	HB_P_PUSHFUNCSYM, 28, 0,	/* PQEXEC */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_PUSHVARIABLE, 5, 0,	/* CQUERY */
	HB_P_FUNCTIONSHORT, 2,
	HB_P_POPVARIABLE, 29, 0,	/* RES */
/* 00156 */ HB_P_LINE, 239, 0,	/* 239 */
	HB_P_PUSHFUNCSYM, 30, 0,	/* PQCLEAR */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_DOSHORT, 1,
/* 00167 */ HB_P_LINE, 241, 0,	/* 241 */
	HB_P_PUSHFUNCSYM, 34, 0,	/* MOD */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_PUSHBYTE, 100,	/* 100 */
	HB_P_FUNCTIONSHORT, 2,
	HB_P_ZERO,
	HB_P_EXACTLYEQUAL,
	HB_P_JUMPFALSENEAR, 69,	/* 69 (abs: 00251) */
/* 00184 */ HB_P_LINE, 242, 0,	/* 242 */
	HB_P_PUSHFUNCSYM, 28, 0,	/* PQEXEC */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'C', 'O', 'M', 'M', 'I', 'T', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_POPVARIABLE, 29, 0,	/* RES */
/* 00207 */ HB_P_LINE, 243, 0,	/* 243 */
	HB_P_PUSHFUNCSYM, 30, 0,	/* PQCLEAR */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_DOSHORT, 1,
/* 00218 */ HB_P_LINE, 245, 0,	/* 245 */
	HB_P_PUSHFUNCSYM, 28, 0,	/* PQEXEC */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_PUSHSTRSHORT, 6,	/* 6 */
	'B', 'E', 'G', 'I', 'N', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_POPVARIABLE, 29, 0,	/* RES */
/* 00240 */ HB_P_LINE, 246, 0,	/* 246 */
	HB_P_PUSHFUNCSYM, 30, 0,	/* PQCLEAR */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_DOSHORT, 1,
/* 00251 */ HB_P_LINE, 234, 0,	/* 234 */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_INC,
	HB_P_DUPLICATE,
	HB_P_POPVARIABLE, 31, 0,	/* I */
	HB_P_PUSHBYTE, 30,	/* 30 */
	HB_P_GREATER,
	HB_P_JUMPFALSE, 2, 255,	/* -254 (abs: 00011) */
/* 00268 */ HB_P_LINE, 250, 0,	/* 250 */
	HB_P_PUSHFUNCSYM, 28, 0,	/* PQEXEC */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_PUSHSTRSHORT, 73,	/* 73 */
	'S', 'E', 'L', 'E', 'C', 'T', ' ', 's', 'u', 'm', '(', 's', 'a', 'l', 'a', 'r', 'y', ')', ' ', 'a', 's', ' ', 's', 'u', 'm', '_', 's', 'a', 'l', 'a', 'r', 'y', ' ', 'F', 'R', 'O', 'M', ' ', 't', 'e', 's', 't', ' ', 'W', 'H', 'E', 'R', 'E', ' ', 'c', 'o', 'd', 'e', ' ', 'b', 'e', 't', 'w', 'e', 'e', 'n', ' ', '1', ' ', 'a', 'n', 'd', ' ', '4', '0', '0', '0', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_POPVARIABLE, 29, 0,	/* RES */
/* 00357 */ HB_P_LINE, 252, 0,	/* 252 */
	HB_P_PUSHFUNCSYM, 39, 0,	/* PQRESULTSTATUS */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_EXACTLYEQUAL,
	HB_P_JUMPFALSENEAR, 62,	/* 62 (abs: 00433) */
/* 00373 */ HB_P_LINE, 253, 0,	/* 253 */
	HB_P_MESSAGE, 22, 0,	/* _VALUE */
	HB_P_PUSHFUNCSYM, 23, 0,	/* GETEXISTINGCONTROLOBJECT */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	't', 'e', 'x', 't', '_', '2', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 15,	/* 15 */
	'S', 'u', 'm', ' ', 'v', 'a', 'l', 'u', 'e', 's', '.', '.', '.', '.', 0, 
	HB_P_PUSHFUNCSYM, 37, 0,	/* PQGETVALUE */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_ONE,
	HB_P_ONE,
	HB_P_FUNCTIONSHORT, 3,
	HB_P_PLUS,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00433 */ HB_P_LINE, 0, 1,	/* 256 */
	HB_P_PUSHFUNCSYM, 30, 0,	/* PQCLEAR */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_DOSHORT, 1,
/* 00444 */ HB_P_LINE, 2, 1,	/* 258 */
	HB_P_ZERO,
	HB_P_POPVARIABLE, 40, 0,	/* X */
/* 00451 */ HB_P_LINE, 3, 1,	/* 259 */
	HB_P_ONE,
	HB_P_PUSHUNREF,
	HB_P_POPVARIABLE, 31, 0,	/* I */
	HB_P_JUMP, 176, 0,	/* 176 (abs: 00635) */
/* 00462 */ HB_P_LINE, 4, 1,	/* 260 */
	HB_P_PUSHFUNCSYM, 28, 0,	/* PQEXEC */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_PUSHSTRSHORT, 38,	/* 38 */
	'S', 'E', 'L', 'E', 'C', 'T', ' ', 's', 'a', 'l', 'a', 'r', 'y', ' ', 'F', 'R', 'O', 'M', ' ', 't', 'e', 's', 't', ' ', 'W', 'H', 'E', 'R', 'E', ' ', 'c', 'o', 'd', 'e', ' ', '=', ' ', 0, 
	HB_P_PUSHFUNCSYM, 32, 0,	/* STR */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_PLUS,
	HB_P_FUNCTIONSHORT, 2,
	HB_P_POPVARIABLE, 29, 0,	/* RES */
/* 00525 */ HB_P_LINE, 6, 1,	/* 262 */
	HB_P_PUSHFUNCSYM, 39, 0,	/* PQRESULTSTATUS */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_PUSHBYTE, 2,	/* 2 */
	HB_P_EXACTLYEQUAL,
	HB_P_JUMPFALSENEAR, 85,	/* 85 (abs: 00624) */
/* 00541 */ HB_P_LINE, 7, 1,	/* 263 */
	HB_P_PUSHVARIABLE, 40, 0,	/* X */
	HB_P_PUSHFUNCSYM, 41, 0,	/* VAL */
	HB_P_PUSHFUNCSYM, 37, 0,	/* PQGETVALUE */
	HB_P_PUSHVARIABLE, 29, 0,	/* RES */
	HB_P_ONE,
	HB_P_ONE,
	HB_P_FUNCTIONSHORT, 3,
	HB_P_FUNCTIONSHORT, 1,
	HB_P_PLUS,
	HB_P_POPVARIABLE, 40, 0,	/* X */
/* 00566 */ HB_P_LINE, 9, 1,	/* 265 */
	HB_P_MESSAGE, 22, 0,	/* _VALUE */
	HB_P_PUSHFUNCSYM, 23, 0,	/* GETEXISTINGCONTROLOBJECT */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	't', 'e', 'x', 't', '_', '2', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 15,	/* 15 */
	'S', 'u', 'm', ' ', 'v', 'a', 'l', 'u', 'e', 's', '.', '.', '.', '.', 0, 
	HB_P_PUSHFUNCSYM, 32, 0,	/* STR */
	HB_P_PUSHVARIABLE, 40, 0,	/* X */
	HB_P_FUNCTIONSHORT, 1,
	HB_P_PLUS,
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00624 */ HB_P_LINE, 3, 1,	/* 259 */
	HB_P_PUSHVARIABLE, 31, 0,	/* I */
	HB_P_INC,
	HB_P_DUPLICATE,
	HB_P_POPVARIABLE, 31, 0,	/* I */
	HB_P_PUSHBYTE, 30,	/* 30 */
	HB_P_GREATER,
	HB_P_JUMPFALSE, 80, 255,	/* -176 (abs: 00462) */
/* 00641 */ HB_P_LINE, 12, 1,	/* 268 */
	HB_P_ENDPROC
/* 00645 */
   };

   hb_vmExecute( pcode, symbols );
}

HB_FUNC( TERMINAR )
{
   static const BYTE pcode[] =
   {
/* 00000 */ HB_P_LINE, 17, 1,	/* 273 */
	HB_P_PUSHFUNCSYM, 24, 0,	/* PQCONNECT */
	HB_P_PUSHVARIABLE, 2, 0,	/* CDATABASE */
	HB_P_PUSHVARIABLE, 1, 0,	/* CSERVER */
	HB_P_PUSHVARIABLE, 3, 0,	/* CUSER */
	HB_P_PUSHVARIABLE, 4, 0,	/* CPASS */
	HB_P_PUSHINT, 56, 21,	/* 5432 */
	HB_P_FUNCTIONSHORT, 5,
	HB_P_POPVARIABLE, 25, 0,	/* CONN */
/* 00026 */ HB_P_LINE, 18, 1,	/* 274 */
	HB_P_MESSAGE, 22, 0,	/* _VALUE */
	HB_P_PUSHFUNCSYM, 23, 0,	/* GETEXISTINGCONTROLOBJECT */
	HB_P_PUSHSTRSHORT, 8,	/* 8 */
	'l', 'a', 'b', 'e', 'l', '_', '1', 0, 
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 2,
	HB_P_PUSHSTRSHORT, 11,	/* 11 */
	'C', 'l', 'o', 's', 'i', 'n', 'g', '.', '.', '.', 0, 
	HB_P_SENDSHORT, 1,
	HB_P_POP,
/* 00072 */ HB_P_LINE, 19, 1,	/* 275 */
	HB_P_PUSHFUNCSYM, 42, 0,	/* PQCLOSE */
	HB_P_PUSHVARIABLE, 25, 0,	/* CONN */
	HB_P_DOSHORT, 1,
/* 00083 */ HB_P_LINE, 20, 1,	/* 276 */
	HB_P_MESSAGE, 43, 0,	/* RELEASE */
	HB_P_PUSHFUNCSYM, 20, 0,	/* GETEXISTINGFORMOBJECT */
	HB_P_PUSHSTRSHORT, 7,	/* 7 */
	'F', 'o', 'r', 'm', '_', '1', 0, 
	HB_P_FUNCTIONSHORT, 1,
	HB_P_SENDSHORT, 0,
	HB_P_POP,
/* 00106 */ HB_P_LINE, 21, 1,	/* 277 */
	HB_P_PUSHNIL,
	HB_P_RETVALUE,
	HB_P_ENDPROC
/* 00112 */
   };

   hb_vmExecute( pcode, symbols );
}

