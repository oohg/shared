/*
 * ieereal.c
 *
 * callable from Clipper only (S'87 or 5.0)
 *
 * syntax:   ieereal( nIEEVar )
 * returns:  char string of length 8.  each char in string represents
 *           the appropriate byte of nIEEVar.
 *
 * syntax:   realiee( cIEEStr )
 * returns:  double.  converts cIEEStr to it's double equivalent
 *
 * compile:  msc 5.1 -- cl /W3 /Ox /AL /Gs /c /FPa /Zl ieereal.c
 *
 */


#include "hbapi.h"

/*
   CLIPPER ieereal(void);
   CLIPPER realiee(void);

*/


union {
        double n;
        char   s[8];
      } v;

/*
 * purpose:  to convert a Clipper numeric to spreadsheet format
 * syntax:   ieereal( nValue )
 * returns:  char string of length 8.  each char in string represents
 *           the appropriate byte of nIEEVar.
 */
HB_FUNC( IEEREAL)
{
    double n;

    n = hb_parnd(1);

    hb_retclen( (char *) &n, 8);
}

/*
 * purpose:  to convert a spreadsheet string into its numeric value
 * syntax:   realiee( cIEEStr )
 * returns:  nValue
 */

HB_FUNC(REALIEE)
{
    char i;
    char  *t;

    t = hb_parc(1);

    for (i = 0; i < 8; i++)
        v.s[i] = *t++;

    hb_retnd( v.n );
}

